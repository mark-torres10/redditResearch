l0k5tmgxa	Mythbuilder46	not_messaged	\N	\N	\N	\N	\N	\N
6bccb	CaptainNoBoat	not_messaged	\N	\N	\N	\N	\N	\N
7sdf3	emaw63	not_messaged	\N	\N	\N	\N	\N	\N
6iig0	ioncloud9	not_messaged	\N	\N	\N	\N	\N	\N
2frrrbmh	SarahMagical	not_messaged	\N	\N	\N	\N	\N	\N
3km2ag4z	Chary-Ka	not_messaged	\N	\N	\N	\N	\N	\N
7o05c	virtualRefrain	not_messaged	\N	\N	\N	\N	\N	\N
4g8hu	bmc2	not_messaged	\N	\N	\N	\N	\N	\N
rivonktq	Wise-Calligrapher123	not_messaged	\N	\N	\N	\N	\N	\N
7v20osyw	fcocyclone	not_messaged	\N	\N	\N	\N	\N	\N
xkzhb	Wand_Cloak_Stone	not_messaged	\N	\N	\N	\N	\N	\N
4t7ne	hipcheck23	not_messaged	\N	\N	\N	\N	\N	\N
6924flpf	uhhmazin321	not_messaged	\N	\N	\N	\N	\N	\N
f2jf06szl	PlanetaryWorldwide	not_messaged	\N	\N	\N	\N	\N	\N
am879eh3	kalkulus4breakfast	not_messaged	\N	\N	\N	\N	\N	\N
b0sw8	HandSack135	not_messaged	\N	\N	\N	\N	\N	\N
hjm48	mrsunshine1	not_messaged	\N	\N	\N	\N	\N	\N
8yqk8	JDogg126	not_messaged	\N	\N	\N	\N	\N	\N
y5c7m	halfbeerhalfhuman	not_messaged	\N	\N	\N	\N	\N	\N
4yvji	fillinthe___	not_messaged	\N	\N	\N	\N	\N	\N
6x7wlyy4	Ill-Conclusion6571	not_messaged	\N	\N	\N	\N	\N	\N
ujjjy	SergeantChic	not_messaged	\N	\N	\N	\N	\N	\N
b6znc	CurryMustard	not_messaged	\N	\N	\N	\N	\N	\N
69rul5bv	improvyzer	not_messaged	\N	\N	\N	\N	\N	\N
8c9v3l2ry	Rasp_Lime_Lipbalm	not_messaged	\N	\N	\N	\N	\N	\N
2s9r5wtk	Onepride91	not_messaged	\N	\N	\N	\N	\N	\N
jugz36zik	OddStadfd	not_messaged	\N	\N	\N	\N	\N	\N
i7fcn	throwaway_ghast	not_messaged	\N	\N	\N	\N	\N	\N
jtgl2e0j2	Agitatelk	not_messaged	\N	\N	\N	\N	\N	\N
sd97mzr	Medium-Oil1530	not_messaged	\N	\N	\N	\N	\N	\N
enmdr	dr_frahnkunsteen	not_messaged	\N	\N	\N	\N	\N	\N
jtgridr1o	Loweiiy	not_messaged	\N	\N	\N	\N	\N	\N
1uhjv09	570erg	not_messaged	\N	\N	\N	\N	\N	\N
t305qb9a	ooouroboros	not_messaged	\N	\N	\N	\N	\N	\N
d4bim	Kierenshep	not_messaged	\N	\N	\N	\N	\N	\N
3fc6d	zhaoz	not_messaged	\N	\N	\N	\N	\N	\N
v90juxgg	Jorge_Santos69	not_messaged	\N	\N	\N	\N	\N	\N
qz47043	ImLikeReallySmart	not_messaged	\N	\N	\N	\N	\N	\N
9zbqh	DebentureThyme	not_messaged	\N	\N	\N	\N	\N	\N
qg00f	Kalruk	not_messaged	\N	\N	\N	\N	\N	\N
ye2um	Benderbluss	not_messaged	\N	\N	\N	\N	\N	\N
b1o3w	poisonandtheremedy	not_messaged	\N	\N	\N	\N	\N	\N
dlne0	FreeGums	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyc64w	\N	\N
b83s7kx8r	SheWhoVotes	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnybhwp	\N	\N
nlcixjvc	Corn_Polkadots	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyd2nf	\N	\N
8s2hi	Hobo_Knife	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnydklh	\N	\N
2av1imis	SewAlone	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnybq9s	\N	\N
4mm0n0z1	PMMEBITCOINPLZ	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyeuni	\N	\N
2usj0pc	brain_overclocked	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx73tr	\N	\N
5uayd9w3	WV-GT	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx57yx	\N	\N
a7k3kk92	JFJinCO	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx5d5z	\N	\N
bb2tboe22	ResurgentClusterfuck	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx6d4y	\N	\N
14wzil	BlueBloodLive	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnxaycf	\N	\N
spfy3p49	The_Navy_Sox	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx5hmg	\N	\N
1aso600e	swipichone	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx70xn	\N	\N
hrg0t	Natiak	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx61fk	\N	\N
67t6faxo	Bobmanbob1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx54dr	\N	\N
pbiu3	ILikeCatsAndSquids	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx9347	\N	\N
a8ahge6e	Jasminewindsong2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx8rq4	\N	\N
101fy9	Lost_Minds_Think	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnxalxy	\N	\N
ilyietxl	TintedApostle	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnwxoxz	\N	\N
pq4a4vgt	JadedIT_Tech	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnww5md	\N	\N
a3027vyc	BAF_DaWg82	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx6we8	\N	\N
3xjvx	charcoalist	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnwwoic	\N	\N
612xz	TheBlackUnicorn	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx1tgc	\N	\N
3bbmh	Yeeaaaarrrgh	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnwwisk	\N	\N
qqavnqxo	Aware-Technician4615	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnwyi19	\N	\N
9vakt	2007Hokie	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jouzb4f	\N	\N
8gtscn1b	Aggressive-Will-4500	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowteya	\N	\N
4cbbdel2	neibles83	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovj89e	\N	\N
5ujm4mpf	justsoicansimp	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jouw4ay	\N	\N
5n8am	spaetzele	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow07x0	\N	\N
nqgzar18	Politics_Knower	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow87ki	\N	\N
49sey	Meatpipe	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovu7mu	\N	\N
5gd71	TheExtremistModerate	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jox0zh9	\N	\N
dtkvdqte4	Tom_Pendragon	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jouz25z	\N	\N
8mdy72b6p	98n42qxdj9	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jouw2kb	\N	\N
v57s6qhn	hexcodehero	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovszt1	\N	\N
s4d78qhw	New_Scientist_8622	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovumy9	\N	\N
e026r	spoobles	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovw8qo	\N	\N
tbdpj	SBRH33	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow13g8	\N	\N
tg1ieqhk	CBSnews	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovtx7r	\N	\N
6ygnb6rj	Randomly_Cromulent	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovwrbj	\N	\N
6x1rtyeo	MaxZorin1985	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovu99f	\N	\N
v9oykdwl	internetbrowser23	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovzfx9	\N	\N
eoob5	-Clayburn	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowcceg	\N	\N
9f5so15xr	Giant_Eagle_Airlines	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovuyxu	\N	\N
mx2zo	jtdusk	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovy5t2	\N	\N
1247ey	Harbinger955	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovxoor	\N	\N
d3hi5	fowlraul	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovvvxo	\N	\N
5qbayp4bx	Slimy_Alias	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow2b37	\N	\N
ncdaf1t2	superiorplaps	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowgrip	\N	\N
vfqn49ge	CalQuentin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovxbcp	\N	\N
pvx7warc	hillybeat	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovxcvf	\N	\N
e1jbz	hoodlumonprowl	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowzkx2	\N	\N
4di8novt	Repulsive_Emu_7495	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joweh2a	\N	\N
lle6a3yg	Admirable-Bike560	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow2rrb	\N	\N
14e9c2	smurfsundermybed	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovcqsi	\N	\N
7l4zq	simoncowbell	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovbbnc	\N	\N
u2ufh9x	OppositeDifference	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovcdbq	\N	\N
4xrc6	Searchlights	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovejv6	\N	\N
mlvu8buq	crabussy	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovbyzs	\N	\N
rdnb27j9	onboquo	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovc89y	\N	\N
n6mp9	sugarlessdeathbear	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovby0d	\N	\N
ppwoobv	ZogNowak	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovakyp	\N	\N
la5mn	AuthorTomFrost	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovb5rn	\N	\N
cad8n4ov	Franklin_le_Tanklin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovduee	\N	\N
2j286ui5	JUSTICE_SALTIE	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovby6v	\N	\N
k58stgv3	Ballistic-Bob	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovfnrz	\N	\N
49062he8	slight_success	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovg8fi	\N	\N
1ms9e9g	Vollmannrama	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovgqt3	\N	\N
8yhhuhiy5	lastburn138	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovgaba	\N	\N
bhrewkuog	CMGChamp4	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovdo0x	\N	\N
tbtjoaq3	DemiMini	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovfl16	\N	\N
8p58t	MrCarey	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovqbmw	\N	\N
gh588nxb	TheBeTalls	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovhyuo	\N	\N
s00qvbni	NeverStopLifting	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovf0qy	\N	\N
d3r6c	F0MA	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovqba8	\N	\N
n5mq33f	bison1969	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovouad	\N	\N
14ds4m3c	jackleggjr	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovvkzi	\N	\N
n6mma	CBJFAN10	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow2p2n	\N	\N
2933qh9f	itsmejustolder	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovs54p	\N	\N
8r5py8y00	Darth_Vrandon	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovs2g8	\N	\N
lfy0nrkz	ObjectiveDark40	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovs6r4	\N	\N
aaq6k	TheEmptyOrchestra	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow03nu	\N	\N
jidod	droidguy27	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joweuvd	\N	\N
mfayz	JohnnyGFX	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow3cvj	\N	\N
2ud2z9k1	monsignorbabaganoush	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowscuv	\N	\N
775uoyty	imrickjamesbioch	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow6y3w	\N	\N
w5xwhcqo	bauN7	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowjilw	\N	\N
rivul	Fox_m	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow6nsv	\N	\N
8bw17wyx	ComprehensivePiano81	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow7zpq	\N	\N
33im5	casanovish	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowhqrf	\N	\N
10r2xt	Navyguy73	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovvt40	\N	\N
7a1ase2t	Icy_Cry2778	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jox7fqq	\N	\N
933e0ajy	comma_in_a_coma	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovoeim	\N	\N
upras36j	RonSwansonSilver	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowfh1e	\N	\N
e5bpbqtx	Picture-unrelated	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowdnta	\N	\N
3yy823la	notleave_eu	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowdan2	\N	\N
4c985	blackcain	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowdvxs	\N	\N
hw79eml3	ObligatoryOption	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowdvtm	\N	\N
vkgr2yra	coffeepot_chicken	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowghii	\N	\N
mfvxyt9f	Excellent_Fig3662	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowdar0	\N	\N
vs38lv3	Jaybetav2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowgac8	\N	\N
nlwmo	2_Sheds_Jackson	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowev9z	\N	\N
roi9a	InternetPeon	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowe5d5	\N	\N
584uxh7l	Selloutkat1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowfmzj	\N	\N
q0goazy5	bluebastille	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joweedf	\N	\N
5prnggez	Murderyoga	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowg8u8	\N	\N
itbx9	spaniel_rage	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowh2a7	\N	\N
8qqgl	jeffinRTP	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowcv2k	\N	\N
4qzov0ht	PleasantWay7	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowdyum	\N	\N
r559z	MidnightMoon1331	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowcxv3	\N	\N
174cr0	Molire	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jownf8s	\N	\N
6474gkq6	PTechNM	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowj9ri	\N	\N
7w743fwz	Bear_with_a_hammer	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joxjrbs	\N	\N
so3lx0sp	tin_ear	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1dc0s	\N	\N
78cyc3ij	unnaturalfood	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnufnwa	\N	\N
3ldy24mb	Rayzou04	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jorhkc7	\N	\N
5qxtj	katrilli	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joy7wu4	\N	\N
12ylsl	eltegs	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joxvr05	\N	\N
nxteb	kkstoimenov	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joy046r	\N	\N
8li29d10	cocacola_drinker	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joxv8k2	\N	\N
2j6y6nrw	Bugscuttle999	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joybmu6	\N	\N
3ag9fm7d	TheLastEmoKid	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0njzy	\N	\N
os4u6	Nyxto	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyw4ft	\N	\N
wnj20	specialPonyBoy	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozajwx	\N	\N
3w6pj2y6	intelligentplatonic	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozjgcx	\N	\N
htvz14t4	WhittlingDan	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozjreg	\N	\N
eptno	XperianPro	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyllj4	\N	\N
16kt6y	Bessantj	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joymxxj	\N	\N
o2mjj3qo	silly_flying_dolphin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joym4d2	\N	\N
6jgqqsb7	dptillinfinity93	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp04y4r	\N	\N
yrlgu	Its_Ba	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joygpxi	\N	\N
9ydc390q	Western-Anxiety3952	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp00veg	\N	\N
ipqi1	Infidel8	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jcp3cuy	\N	\N
32p7wg4b	AFlockOfTySegalls	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jcp71cd	\N	\N
sth2z	freddiethebaer	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jcps7s7	\N	\N
4db72jwz	NotBadAndYou	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jcqfmk3	\N	\N
25r07b83	Georgiachemscientist	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jcppigr	\N	\N
14uhv	gnudarve	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnu6a8l	\N	\N
cmcsk7sv	WeCanDoThisCNJ	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnwzdnk	\N	\N
5eq0c	DracoSolon	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnt4het	\N	\N
624t6o1	oldguy76205	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jntmrjr	\N	\N
3yilh	luckykobold	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jntcfyl	\N	\N
5etg3	Msbossyboots	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jntnu87	\N	\N
3724187	karmaapple3	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnu4odp	\N	\N
1l8w84ld	praguer56	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnu6o5i	\N	\N
1ysiqh4	thesonoftheson	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnvkhgs	\N	\N
tasf1324	musicmanforlive	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnxw01y	\N	\N
crbby	JMRoaming	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnxm3nt	\N	\N
tawjsr4s	No-Tangelo7363	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx6ucc	\N	\N
tx11ug34	Green1578	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx7oha	\N	\N
3si0e	TallahasseWaffleHous	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnx9jnx	\N	\N
ju091	Filmmagician	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyai5b	\N	\N
lj1sz	raistlin65	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnxacc3	\N	\N
s8laneoe	rawchallengecone	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnxhnsp	\N	\N
pt09m	calvinnme	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnzegco	\N	\N
r3yd8hvi	koyaaanisqatsi_	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnzlk3a	\N	\N
91wa3	superduperm1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyq09n	\N	\N
qxmwkzww	Koko22Loco	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnwl152	\N	\N
4ukp3	woodenbiplane	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnwt1zs	\N	\N
ifa569ms	cerealsimple	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnwn3q6	\N	\N
nimy0mz7	iblameautocorrect	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo1lzp7	\N	\N
lbf69u9r	cheese_weasel22	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo0xxkv	\N	\N
odgoy8oa	GunterBoden	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo1jl1t	\N	\N
261bgs9k	tnakahara	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo0lk7g	\N	\N
6wu0xw9b	Impressive_Jaguar_70	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo0vc1a	\N	\N
4wkiu8w6	churchin222999111	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo0yp2f	\N	\N
37k23689	reallythinkso	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo0mevs	\N	\N
9ex6xqvq	Lieutenant_L_T_Smash	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4dkhr	\N	\N
6ng72f4f	Ok_Neighborhood5832	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4hra7	\N	\N
r5jnrhlm	PhoChunKookie	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4t5hr	\N	\N
mm48d8k2	EmoSongsNReadAlongs	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo51jra	\N	\N
cvr41wawf	RedditWater7	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo6aaau	\N	\N
ffvepm99	hastewaste95	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4eenx	\N	\N
xszzd	Fubeeo	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4ki3a	\N	\N
64xoc9f02	AnomalouslyPolitical	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4frpe	\N	\N
lqhi63f5	Corpcasimir	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4ktan	\N	\N
2y35ggd6	anthro28	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo6bk0h	\N	\N
8iw9h	reaper527	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo66muq	\N	\N
11t61y	the_chosen_one96	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4db2a	\N	\N
4kvep7by	ccg5058	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4j1y8	\N	\N
tw2cu18d	Enjoys_Equally	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4k89r	\N	\N
hkfk7n4t	irony_oblivious	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4rroe	\N	\N
bth90ot1	_Diggus_Bickus_	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4ca5y	\N	\N
4j8dczqg	winkydinkvw	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4fle3	\N	\N
3xpxgnz5	PeppercornDingDong	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo481os	\N	\N
kxo6z	_R_A_	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo5ych9	\N	\N
8a7jpv12l	FloppyDonkeyDongss	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo8o5yr	\N	\N
1kiroxl2	Obamasamerica420	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jopsq1m	\N	\N
60l29	nukalurk	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo55dum	\N	\N
3zgks	Riggs909	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo8bvrt	\N	\N
c8dl2p4s	Illustrious-Leg-5017	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow3b0m	\N	\N
9mtjy0zzf	TheFriarWagons	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowpkuk	\N	\N
um3nl7l4	Rust1n_Cohle	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jow388j	\N	\N
9u2ebsi9	Efficient-Albatross9	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowb5dd	\N	\N
dtj997x3	thekeithhose	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowmjuf	\N	\N
ebqowmvu	Legal_Flamingo_8637	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowbmzu	\N	\N
2v4sncb0	NotMSUPD	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowfkid	\N	\N
k5jr0gml	magicdrums	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jox5muw	\N	\N
tmm3htrp	Practical_Put_3892	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jox5ufp	\N	\N
vxohfv4d	DemCastAdmin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowfl4d	\N	\N
fdo19k6	KnightRider1983	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joxzosi	\N	\N
eqewj	Parabellum8g	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joy2x5c	\N	\N
f51p5ox7	Libtard69696969	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyfv7z	\N	\N
t6g2mi5a	Independent_Onion542	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joxug5s	\N	\N
vy9wj9us	CantHackItPackIT	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jox7bqs	\N	\N
5m4xx8ml	Eagle_1776	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyuhun	\N	\N
voukg27l	jimmyspank12345	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyvu3n	\N	\N
934xj4ol	johnnyg883	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz0r2i	\N	\N
y8oa7	MerlynTrump	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz3vjn	\N	\N
qhk1hudy	Dirtface40	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz9gvp	\N	\N
n5bhaaky	ScoogyShoes	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyhy23	\N	\N
a05ov7jh	xPropagand4x	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joys0ch	\N	\N
rj375rmv	skepticalscribe	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyxfco	\N	\N
15p34b	useablelobster2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyo6wd	\N	\N
aoc0jvhak	BionicBoBo	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz15i7	\N	\N
2j3io422	iggyspear	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyx2pw	\N	\N
2nyvrax3	sparkplugg19888	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyp5of	\N	\N
5zmi7	FermiAnyon	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyzmte	\N	\N
20373jwx	Bogdinamite	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyyvu5	\N	\N
6xr8e8up	The_Fortunate_Fool	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joygk9m	\N	\N
ajcphg5o	Accomplished_Way_323	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyuteg	\N	\N
8upfmnri	Nopenagada	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joykv4i	\N	\N
clceergo	SgtVader501st	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz2hso	\N	\N
2vzjlxkd	tehcoma	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyypds	\N	\N
5nwuwt648	Misohoni2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz526p	\N	\N
g4igzur0	that-guy-blimey	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz5bxc	\N	\N
5nsyx9vep	Once-Upon-A-Hill	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joys3oz	\N	\N
64vi7	Jack_Sandwich	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz0nap	\N	\N
3wgvyq32	EmperorToilet	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyzwi7	\N	\N
icz31cnq	ChitlinNoodleSoup	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joxvpcj	\N	\N
rwhuzc5c	Sin1st_er	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joy0rku	\N	\N
52x0cab0	JV2535	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyhski	\N	\N
a2wbvs1z	DullPunk	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyb6mj	\N	\N
2iqrp9y1	YoungBassGasm	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joybjc4	\N	\N
d8tcn	KC5SDY	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joy1m1u	\N	\N
hyu7s	ObadiahtheSlim	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyiz33	\N	\N
5rbfj8t3q	DrTartakovsky	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joy89ub	\N	\N
caeld1h	Meppy1234	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyog17	\N	\N
8j8zyl63u	TheodoreKurita	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyqjhr	\N	\N
ejwp6	RedditsLittleSecret	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joy8jhy	\N	\N
6mgig	ButRickSaid	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz1kw8	\N	\N
5df9bglk	Aggravating-Scene-70	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joykqx0	\N	\N
eed8s	superarts	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz0gkb	\N	\N
3cr2mqeq	WillowIntrepid	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joyawgm	\N	\N
53xqk	4blockhead	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joh91nm	\N	\N
8xcwn	MC_Fap_Commander	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogp4s0	\N	\N
q4srdteg	Theechoofme	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogp1v9	\N	\N
c3z4em2j1	National-Spinach8056	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogiztu	\N	\N
12w7nuge	bpeden99	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogixv8	\N	\N
3xvbeaz0	344567653379643555	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogljav	\N	\N
8elzvtrnv	thesirensoftitans	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogpw0f	\N	\N
144s2s	richardj195	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogn27a	\N	\N
1oyli8zx	TLKimball	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogwnhw	\N	\N
7iyv2	MrLurid	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogvpx6	\N	\N
34rq0	InterPunct	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogxygc	\N	\N
b0fdx79b	BitchfaceMalone-III	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogxlz7	\N	\N
7aj7jshl	spooky_ed	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogydjx	\N	\N
2df5mjev	HugeCartographer5	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joh26zk	\N	\N
8fzx0jm3	NinJesterV	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jog3344	\N	\N
vlaay7h6	4levelclover	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jog2tz9	\N	\N
f1ada1x6	Squirrel_Chucks	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joge4zl	\N	\N
bocsf	thepartypantser	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogjmyr	\N	\N
a8qebebds	52163296857	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jog5ky4	\N	\N
849ko	GeebusNZ	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogazmh	\N	\N
638a58sx	Bennghazi	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jny88ue	\N	\N
adt8jyn1	1eyedbudz	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jny6w45	\N	\N
3hvrm	bostonmolasses	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyg1xo	\N	\N
5egneozv	Dictaorofcheese	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyd0la	\N	\N
75ft90x4	Desperate-Ad-6463	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyb3se	\N	\N
5ex19u7z	vakr001	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnydc73	\N	\N
a05hpgi0x	rdcomma	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnycct3	\N	\N
kldkg	RareBeautyEtsy	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyqjjw	\N	\N
3ad4y	Randolpho	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnykifx	\N	\N
bbmg7o5z	ob1dylan	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvips9	\N	\N
5zmnp73u	skoorb1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvp68b	\N	\N
phsdegpk	Able-Theory-7739	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlwfvgb	\N	\N
mt5ognfh	waitforsigns64	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlw5p9u	\N	\N
653m1	slouched	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlx9kq7	\N	\N
aatba	maxthepupp	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvwlud	\N	\N
m2f4dtrv	anonbene2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvzfhi	\N	\N
bpe8kkch7	h20poIo	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlw5a2c	\N	\N
neufg	polarpear11	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlwhiu7	\N	\N
24xc137b	rellicotton	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlwsa6r	\N	\N
ggt2yf5w	NormalNeat8685	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlwts82	\N	\N
wu02s	Taztiger72	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvp874	\N	\N
9z1kt8	Ofbearsandmen	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jluuprs	\N	\N
5sctzg1j	YallerDawg	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlun3xf	\N	\N
3esjp7tx	agjrpsl	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlva5eg	\N	\N
ja4lq	LesserPolymerBeasts	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvj278	\N	\N
8mhabzn7	CPfromFLA	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvbbxl	\N	\N
9ybqqa68	Own_Entertainment847	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvv2pb	\N	\N
1rfqluhg	RedSpartan3227	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlw9yvg	\N	\N
w271wtl0	UnusualAir1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvg984	\N	\N
3af89ccx	duke_awapuhi	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlxlal4	\N	\N
2ekp01hm	AceCombat9519	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlw94j7	\N	\N
cfvcwapp	Creative-Ocelot8691	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlvttuu	\N	\N
kzi2v8o8	Ornery-Gas-1730	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlx8ltz	\N	\N
gtxx2	jcbmths62	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlurlfx	\N	\N
78q4l82c	mjcatl2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jlxrq54	\N	\N
3w7eir3	Jimbojauder	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnye8mn	\N	\N
5iznl	sumguysr	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyo5mc	\N	\N
vhhsogwe	BuyOutWallStreet	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jny63az	\N	\N
f7qti	insipidgoose	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jny7ki5	\N	\N
4d930qas	Makachai	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyb350	\N	\N
n6jouylf	josuelaker2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnycemy	\N	\N
ezi17ujk	Chitown_mountain_boy	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyhu4v	\N	\N
ahcmfw8	canuckcowgirl	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnymfbw	\N	\N
1a395kqk	mehlaknee	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyoepj	\N	\N
47p09v3m	Madmax8080	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnylb0h	\N	\N
ga0hc	calumin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jnyng3q	\N	\N
jjdgf	rucb_alum	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	johmoxt	\N	\N
hsl7g	tshawkins	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joic1qg	\N	\N
3cux3	ciaran036	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joj5qp6	\N	\N
lowdc43m	Far-Adagio-7375	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joj76t5	\N	\N
h46xgual	Saturngirl2021	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogy49d	\N	\N
6b29t	calindor	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joh217g	\N	\N
9w60dcsx	Lukey_Boyo	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogvuar	\N	\N
575wz0bd	Itchy-Mechanic-1479	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joj1iqg	\N	\N
3ocqb	oced2001	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joe1evy	\N	\N
48jy32ol	Rental_Car	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jofkk25	\N	\N
19p2zmg1	TitanMU	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	i8p577t	\N	\N
dnj07fku	Slow-Vehicle-282	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	iizmn3d	\N	\N
v4dec4xu	WeTheLions	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	j14zj41	\N	\N
h24uz4dy	SharpPoint8	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	i4b9v35	\N	\N
4wl4e59s	atpierce2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	iib5126	\N	\N
1m4pdg41	TheSmiling_Buddha	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	icv0uoq	\N	\N
7w219k2p	Idriselbowz	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	im479wg	\N	\N
q2u9sihn	alonela	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	in5m16d	\N	\N
b5bnekp4	Constant_Fun_7326	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	ibun0g9	\N	\N
lgf1c25d	SpecialistComposer44	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	inhl8u1	\N	\N
apaa6ixe	Intelligent-Travel-1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	iolu8oi	\N	\N
9szpc2c	ARY616	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jm0pes2	\N	\N
9gf0m82v	Olong-Jonson	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jm0hf4f	\N	\N
rozr6e9j	StayYou61	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp2onjj	\N	\N
deds9d559	--R2-D2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz9izh	\N	\N
ahhyn	FnordFinder	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp06jzu	\N	\N
1fsf2dhy	smimton	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0lok0	\N	\N
82137c96	LetItHappenAlready	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jop1v6y	\N	\N
80vw2mph	Tuco86x	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo5m74h	\N	\N
3ce9h	Wadka	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4knu9	\N	\N
12oic1	frigginfartface	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4z9hj	\N	\N
5tu0k	ivan34	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo54p6e	\N	\N
ttkge2ys	This-Independence-50	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4m56q	\N	\N
as2iq	8K12	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4mjpa	\N	\N
4a91t	richmomz	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo996w6	\N	\N
2vksf9zl	RainbowReclaimation	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jobdbdq	\N	\N
boejb	thedenofsin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joo156r	\N	\N
xhqid	jmartin251	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo5umln	\N	\N
d29z7	redditor01020	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo5kes9	\N	\N
325jf	gprime	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4rvq3	\N	\N
13yk6q	BeachCruisin22	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo4rbb5	\N	\N
vfwnvxs1	No-Attempt-161	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo52w4z	\N	\N
5jbl7gol	LifeIsBetterDrunk	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jo5kuf0	\N	\N
qekks	141Frox141	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz7v2n	\N	\N
uywghyii	Expected_Guests	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowcvhk	\N	\N
ov7i0ok4	Raider-bob	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowm727	\N	\N
quxrzeeq	breakneckjones	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz39cp	\N	\N
ddojsni8x	brilliant_object5730	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jowc56x	\N	\N
13qky9	cowdrey_matt	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozv82w	\N	\N
54sus0o8	bigmistaketoday	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0xbp3	\N	\N
vt8qxvke	Corrective_Brutality	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1qicg	\N	\N
71ucu	bozoconnors	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozyhb6	\N	\N
7job6kcv	Few-Brilliant-426	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp042qg	\N	\N
loe1y	RhaegarsRevenge	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp091lc	\N	\N
w1t94cop	HamletsRazor	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0h805	\N	\N
9si8a	Dreadkeeper	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp01hap	\N	\N
1p4jlrux	mantistabagin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0ab09	\N	\N
biry1	deadzip10	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0t6gh	\N	\N
1196lk7s	gentlemanA1A	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp14jee	\N	\N
eqy4t3d2	RullyWinkle	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp15xdj	\N	\N
pp1hk	polerize	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp18kq6	\N	\N
apb15	DaddyD68	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1b7bs	\N	\N
ap8d45l	Chewy_LewisThenewsz	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1q9wl	\N	\N
73lai	Nucka574	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1qrly	\N	\N
7m5a74v9	SheCallsMeBigPapa	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1tiqm	\N	\N
2ac2tp5f	etbillder	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp26mu7	\N	\N
a16dn0nx	sparktheworld	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp2bjn3	\N	\N
ciluo8kb	Artistic_Mouse_5389	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1xfzv	\N	\N
p0sq4kr0	Rodger_Reddit	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp2540g	\N	\N
9imwkwq3l	Anakin-groundrunner	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0e7ay	\N	\N
ffx3vciv	Treddf45	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0hpra	\N	\N
9yz3e	triggernaut	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0f3pr	\N	\N
z430e	richard0930	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0du9o	\N	\N
en7tw	Mississippiscotsman	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0vwqn	\N	\N
5ggr82zd	1_Cold_Ass_Honkey	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0dizz	\N	\N
r0oqk294	MaroonNuggz1138	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0nm97	\N	\N
50vb7mh	noonehomenow	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0dmpa	\N	\N
sb361fri	3pxp	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0hvka	\N	\N
vnfr13et	bruh_wut69	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0gz86	\N	\N
8z6em9s0w	Any-Flower-725	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1huv2	\N	\N
eqa0uf18	MonkeyThrowing	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1854i	\N	\N
siut2fbt	st3ll4r-wind	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0fo17	\N	\N
si3fv8tv	samefoldsamefold	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp11pxe	\N	\N
16bwnt	DogBeersHadOne	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0kh8y	\N	\N
atljpou99	TheRealActaeus	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1cc1y	\N	\N
6dfcax0t	alexyoung92	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0sd9g	\N	\N
9ghpnqwr	Litmus44	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0mfjy	\N	\N
50a4n3qs	hackmaps	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1de11	\N	\N
nlnzllb3	Massive-Fly-6649	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0r5id	\N	\N
a3o5mm4vj	Financial_Distance53	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0wefi	\N	\N
zr0q9	gooseberryfalls	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0mvn9	\N	\N
4bnqbrsm	petergriffin999	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp19iqd	\N	\N
mtywxba8	DCinMS	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1cm9a	\N	\N
syy0ts2k	CoffeeWillMakeMePoop	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1f3dt	\N	\N
141725	DarkMark94	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp149pi	\N	\N
13k0ki	JTuck333	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp165wl	\N	\N
w5do0fic	Conduit1245	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1vke4	\N	\N
4l7ienbi	Chiaki_Ronpa	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp20kfr	\N	\N
11rimi	Flint__Sky	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp28f8h	\N	\N
a51emd0d	TapInternational3605	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp279lv	\N	\N
7s9uj	uniquecannon	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp23gbf	\N	\N
djeqz	TitanicJedi	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp2km0m	\N	\N
v1lu19h6	fridayimatwork	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp2r53e	\N	\N
cgf7qteeo	Castyirony	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1z6r7	\N	\N
5k5upseb	Ashurbanipul	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp2mfc6	\N	\N
pcybo	DJ_Derack	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp2trk9	\N	\N
5eu3io4n	TacticHalo	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	iv8d9c2	\N	\N
sxkcvoxb	zootayman	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jij97ht	\N	\N
1u1g5alb	LakotaPride	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0wlcb	\N	\N
17efxo	the_kfcrispy	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1s03u	\N	\N
d2sciyr3	WinDifficult8274	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1mvgk	\N	\N
a3k4ojst	cottonr1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1thvq	\N	\N
ad36ic7m	Thorean0907	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp11tus	\N	\N
7oik8ju9	larrykarp	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp03if9	\N	\N
ihhun	prawnhorns	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozhhmv	\N	\N
qub6odhl	MichaelSquare	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jogx5h9	\N	\N
w8h3uwws	Strange-Dress4069	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	johypws	\N	\N
g3nw2	thegreatincognitum	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joi0ppo	\N	\N
6duobliju	MilkyWay9231	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	johqtwp	\N	\N
2qrofmnk	AWardfiction	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joi5sqh	\N	\N
a95nfpb8x	respek_the_tails	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joiahrc	\N	\N
3ygs1eazu	CozyCoruption	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	johuu9l	\N	\N
6ewp4jrv	ENFJPLinguaphile	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	johx3id	\N	\N
cy35u0kt	blakevac	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joidz8w	\N	\N
snf8u8mu	FauciLiar	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joijnwf	\N	\N
4w3ga65ow	sjsgswfan90	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joiqhun	\N	\N
2ztkd8a	concieted	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joiedxa	\N	\N
aerkqpw0g	Axotalneologian	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	join41q	\N	\N
qlgpajd	SwiftAndSlick	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joieexk	\N	\N
veowt	hiricinee	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joimtta	\N	\N
1diah	tsdguy	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0owwh	\N	\N
6gkogbeq	GrayBox1313	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp238zo	\N	\N
3i8thcml	clocksteadytickin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joypsr0	\N	\N
vfnk8	__erk	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joz2slh	\N	\N
8lyo9mds	Godmirra	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozt8in	\N	\N
9xuq7	henrysmyagent	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joztaze	\N	\N
h8sgq	bigcalvesarein	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jovu5ks	\N	\N
stmqxj0v	Desperate_Wafer_8566	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joq7sk7	\N	\N
sxwdtgx	mb5280	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jori697	\N	\N
3dxcg	Astacide	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jorxf07	\N	\N
njyn4	humbuckermudgeon	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jos0wi2	\N	\N
5f1y5u4ob	Jonnykpolitics	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jorvvge	\N	\N
75x9weyp	Snoo54249	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jorbf4d	\N	\N
7nwlabkw	johnlal101	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jotnsbr	\N	\N
nvaxr	TangentTears	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joybrhi	\N	\N
84knxdcy	ProneToDoThatThing	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jopr1j7	\N	\N
1x4e6tif	Walk1000Miles	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	joplx1q	\N	\N
chine	rekniht01	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp08mk2	\N	\N
6nfskvw3	JJ12622	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozjaof	\N	\N
jn0nv	newnemo	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozxbjv	\N	\N
dj1cm4cvk	OsellusK	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jozd55k	\N	\N
ab2bowl1	SaveUsFromPubDeath	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0xqu5	\N	\N
ctr65idk	PokieState92	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1swz6	\N	\N
6q5s5	jddoyleVT	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0h4o5	\N	\N
mi348su1	pinetreesgreen	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0hfrf	\N	\N
4edtq	kracov	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0h2z2	\N	\N
l3mycx93	darth_wasabi	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0llp4	\N	\N
qntqj9b5	PRPLpenumbra	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0ht80	\N	\N
d73zx	Illuminated12	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0h7ln	\N	\N
42904ftg	azacealla	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0nvup	\N	\N
174wcm	bigolfishey	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0mgxx	\N	\N
d2dsbfh9p	Remote-Link8612	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0ijdp	\N	\N
6nvynr0q	KennyDROmega	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0kgx3	\N	\N
pnbivew9	olddeebs	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0gzqg	\N	\N
57buvlrs	LuminousTights	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0qbgj	\N	\N
615jy	gearstars	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0ibcc	\N	\N
1bhbce6e	p001b0y	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0ig2i	\N	\N
j6yg3	prodigalpariah	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0je8i	\N	\N
yvy7weh	DJGlennW	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0otpi	\N	\N
2fvmjl6x	October_Numbers	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0rrcc	\N	\N
11x2a6	rifraf2442	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0lo8b	\N	\N
299ay0or	jrsinhbca	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0lr7z	\N	\N
pyrof	Beforemath	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0jkla	\N	\N
fun6d	xvandamagex	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0mh3p	\N	\N
9vp7ukvp	CantReadGood_	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0x80e	\N	\N
10enw0ud	cardinannigans	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0iz9y	\N	\N
6df20fzh	philkensebbenhaha	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0okgi	\N	\N
3731c	mces97	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0qr2y	\N	\N
41u5ojgl	theforceisfemale	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0prz8	\N	\N
eepue	dwors025	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0krgr	\N	\N
641piffy	quietset2020	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0u051	\N	\N
jm9d3pbh	Wine_Women_Song	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0r8up	\N	\N
s09y3	red23011	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1ax9v	\N	\N
8pml2fpdt	south3y	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0hqeh	\N	\N
8zzqjqkc	Soggy_Phone_8387	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0kezl	\N	\N
1yhubxuy	spacegiantsrock	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0m9yn	\N	\N
4y37jqd0	warpedashell	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0n59d	\N	\N
7j4ja	Helfix	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0esl6	\N	\N
5l9ejfpq	HallucinogenicFish	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0jaap	\N	\N
ay89j6t71	No-Programmer-7253	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0g3qf	\N	\N
10m2rv	Injest_alkahest	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0huxj	\N	\N
4tnhzzft	MidwesternWitch	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0ftq5	\N	\N
l24gn9uw	Eric_in_America	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0xsfh	\N	\N
e5fianxx	babysinblackandImblu	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0dbfb	\N	\N
9b9ii	who519	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0kuwx	\N	\N
g6u85	tommfury	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0i5r5	\N	\N
cl1qfvmtt	discussatron	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0jto3	\N	\N
5z1h74j9	def_indiff	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0t2z7	\N	\N
2or8gz	Skip12	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0k6bv	\N	\N
19dy85t6	Renorico	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0usna	\N	\N
3y0d7dt8	MynameisJunie	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0v4hd	\N	\N
14h7ep	CountrySax	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0jmbi	\N	\N
38a8a	schrod	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0wv02	\N	\N
15koms	DBCOOPER888	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp13vnb	\N	\N
2kk0n8yl	tek_ad	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0qvdu	\N	\N
477cka1j	Roanoke1585	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0tb85	\N	\N
m0jyjdz	OnTheFenceGuy	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp11c94	\N	\N
cxbna6k	manhatim	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0kozu	\N	\N
4hun6	nuckle	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0rs8g	\N	\N
qpzbs	Circumin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp196c1	\N	\N
8iw44ins	brianishere2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0oy30	\N	\N
ymusjd1	ReasonAndWanderlust	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0x4zi	\N	\N
12dsh2mz	Fragmentia	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0ztf2	\N	\N
55ungni4	Impossible-Pie4598	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0odwp	\N	\N
1cr18x05	mzialendrea	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0sbz8	\N	\N
3jwxkz0w	MarkHathaway1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp0wbj6	\N	\N
9qcd1ob	Riversmooth	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1f9oh	\N	\N
janw1acd	FlutterbyButterflyMS	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1bzqa	\N	\N
6wgcr	lordlaneus	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1czgo	\N	\N
8xy2hhck	PapaBeahr	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1x48l	\N	\N
18k2kz81	Gaeneous	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1i0oe	\N	\N
3gpj84b3	bandix01	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1u7eb	\N	\N
hrdcy	WhileFalseRepeat	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1lcqu	\N	\N
aao672dk	StainerIncognito	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1rmiu	\N	\N
cbdqebom	bob_scratchit	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1zn04	\N	\N
sm7bxufy	joeleidner22	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1ovia	\N	\N
9okho	ebone23	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1wens	\N	\N
szmya	houstonyoureaproblem	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp20l2b	\N	\N
v4uhjs8h	ResponsibleMilk7620	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1niv4	\N	\N
eltce	ThreeHourRiverMan	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1q83q	\N	\N
ul6mxq1f	Metal-Barcode	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1yh6g	\N	\N
1p44vsh0	kee-mosabe	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp22psr	\N	\N
3c71ibc5	ApatheticWithoutTheA	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1thju	\N	\N
bgba0	UStoAUambassador	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1wuhc	\N	\N
9i9wb	TheNamesClove	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1t6vj	\N	\N
15rg88	platinum_toilet	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1w9wc	\N	\N
d9vvy4iw	FreeByrdDeVille	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1sa4i	\N	\N
hclr3ili	mumeikokoro	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1uv0r	\N	\N
9ks9pqnh	Tin_can69	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1xcd0	\N	\N
kwwo5	bigred9310	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1re0j	\N	\N
e8ff4	brayab	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1t6o0	\N	\N
1akw2zla	DjMD1017	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1bx3b	\N	\N
lgszqzfr	utopia_forever	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1arqx	\N	\N
t2i8jzfa	Tadpoleonicwars	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1h0er	\N	\N
a7l17k9jh	AdditionalChard520	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1bfjl	\N	\N
ckae	grondin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1db92	\N	\N
3gs4o	ewillyp	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1dl77	\N	\N
nm0i7	Number-Thirteen	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1hk95	\N	\N
6dap3g7o	AcrobaticSource3	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1l30r	\N	\N
p62smtlg	hello_world_wide_web	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1svx3	\N	\N
4ae3e	goldbricker83	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp1okyq	\N	\N
bx72t811c	NoLack5170	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp208lz	\N	\N
afjyr	Rocketsponge	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp21nfo	\N	\N
2fruo332	HybridEng	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	author	jp23hgt	\N	\N
syiazbzh	Elivagar_	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
tbgjuzkh	HenryGray77	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
cpqy74j0t	Muted_Violinist5929	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
14fms2	Cerus98	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
i22yaoe	username36610	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
5db1d	Taidaishar	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
2ezckrei	gamer_guide_64	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
cknhj	Doopsy	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
7ryab19b	Maleficent_Slide3332	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
7rkfhvql	TheInvisibleFart	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
bs94y2ig	Ok-Profession-3312	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
vfrizkxd	SurelyNotaSmartAss	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
w7q83vo6	shrike_999	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
fursn	GOPokemonMaster	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
accbc	EphemeralFate	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
b76q59m1	142Ironmanagain	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
nuy3m	bmalek	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
86rj0	ngoni	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
n08zfd8y	cumdumpsterfind	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
iqutr	wck3	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
bh8cv58a3	Civil-South-7299	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
pwytp5rj	ihatetothat1	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
14t9lm	ScrambledEggs__	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
qxygq	Pulsarultimus	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
58ayihiz	Zealousideal_Fix_181	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
12gg01	thedrd2k	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
a41jxi06	DrewDownToLearn	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
jaro04dd	chudwick80	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
4zqju	gruszeckim2	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
87rv8tjj4	SecureAd4101	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
bcmx7oqps	_The_Kurgan	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
g3lkm	trollyousoftly	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
6mr0o	Yogi147	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
yn6nmcx	weasel286	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
3ja0it4i	KNWNWN	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
dgpqlq1y	_Kyrie_eleison_	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
a1hw355p	Slske	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
o70wxkn	_night_cat	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
orvkml6a	2ToTheChest	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
c9foqd9os	Gitmogirls	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
1v08d9fr	inthesinbin	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
ictoq	thehomeversion	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
3ojz2t1e	KarmicComic12334	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
8vnhc	alvarkresh	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
a4zu1	sten45	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
npesv	Trevorblackwell420	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
7jf3p6zl	Delicious_Adeptness9	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
5hjodlwe	OtakuAnthony	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
4fxv2	etherdesign	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
hy4dcqxd	OverallStorm65	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
8amqo2lz	Astro3840	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
7qlwn3w8	CatPatient4496	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
7h0rx	joc1701	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
9eu97	DBDude	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
ra5wm	always_find_a_way	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
519y21kv	jimjam721	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
c3v2kursc	DaisyB1923	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
8663g	puss_parkerswidow	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
4uzxs	ronin1066	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
b4m4g	Clone95	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
3gpiw1y6	punarob	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
a0w0gxwg	LightingTheWorld	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
9fztfo2u	PerceptionOrganic672	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
859xzvu9	No_Brilliant5888	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
122d4w	MrRipShitUp	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
b79xx35ls	TifCreatesAgain	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
fp32vqyv	Hereiam_AKL	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
ejx147l4	Icy-Philosopher5446	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
m4nuz	AngryZen_Ingress	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
v5ee3u3b	Not_BobBarker	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
dncm9nm0i	wrongagainlol	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
13x5a6	sdlover420	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
93hz44chb	PhoenixTineldyer	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
cl8pg4njj	ZealousidCee3	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
9zyng	ZSCampbellcooks	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
z6zjh	woolfchick75	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
kuuvzxj8	MakingItElsewhere	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
ib3rs	thevaere	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
3h60u	Frank_Jesus	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
hf1u1bwk	AvsFan08	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
asdup68f	Racecar22b	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
dhyu2	jellyrollo	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
tnnlupdt	mods_on_meds	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
4b0z1	marji80	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
79dsd	nucumber	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
4vpdh	Racer20	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
a1w10sav	IrishRogue3	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
823dcrm0	Few_Professional6210	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
40xzd	smsmkiwi	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
6n5mjd3f	Inside-Palpitation25	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
1bxumi8	BadAtExisting	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
9mul5r230	DrakeFromGrapeFarm	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
1sj4kvy9	nflxtothemoon	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
9b70ddf7	75839002	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
99alx	captaincanada84	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
11cidq	routerg0d	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
78lv1	FriendlyDespot	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
8yjgp9mpa	8Martinez-958	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
8d9exb9	tombaba	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
4t5paxn3	rexspook	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
bzt7r4m3	ProfessorTicklebutts	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
16ba0nmc	Demonakat	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
x1sbi	aaapril261992	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
y65o9a3	xKrossCx	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
12c7ezlu	xeroxzero	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
pey8n	shrekerecker97	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
m6lot	somabeach	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
ammro	onioning	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
6hbwo	Minus67	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
vz3nzey6	RitzyDeer	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
5o5n2e3w	Bandit1961	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5rpl6	Who would be surprised that the guy trying to erase black history is a racist?!?!	\N
16oixls5	HMDavidXIII	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5xwxh	It doesn’t matter, they can pass whatever they want, but it won’t get through the Senate or past Biden, the House doesn’t have the authority to do much of anything unilaterally. In other words they don’t control security clearances, they can  formally request that’s about it.	\N
6s8gm	Stooven	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp5073h	Just like when he he said Florida couldn't afford to have Gillum become governor and be "monkeying around" with the state policies. Funny how he always seems to find racist rhetoric coming out of his mouth when talking about black people doing anything.	\N
7zusaaiu	Cool-Presentation538	messaged_successfully	legacy_data_migration	2023-10-13T06:14:42.914668	observer	jp6e6p6	WE HAVE LOST THE SUPREME COURT. It is corrupt, compromised, and complicit in the Republican attacks on Democracy.\r\n\r\nThe Federalist Society has cooked the books, bought and paid for Justices.\r\n\r\nResign, or impeach. \r\n\r\nThis nation, and all those who lived and died for our country deserve so much better.	\N
3hb8h	cficare	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
e7egm	longsh0tt	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
ab8sv	petal14	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
u0si4	prattchet	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
c2i4e	MarcusQuintus	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
asbf9	itemNineExists	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
87h8kco3	tapastry12	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
wmxh	ljheidel	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
d5mquwod	UltravioletAfterglow	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
62wjx1m1	ChuckVowel	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
4stjn	syracusehorn	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
51mugzx0	IntrinsicStarvation	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
5fm45w7v	LurkerFailsLurking	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
13n0egw9	Trippedoutmonkey	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
i7xoa	LegendaryOutlaw	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
1nwyjg23	BringOn25A	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
i0j4n	b95455	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
vlkj8g4	TheUnknownStitcher	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
3z5jj6vi	sharingsilently	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
3q6lk8ck	Killerkurto	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
hzq9l1sq	Howhytzzerr	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
3i9nzyal	BabyMFBear	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
8d3808n7	not_productive1	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
gqaui4om	WholeWheatCloud	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
eewrlp3b	FrostySquirrel820	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
jckbmbri	contemporary_romance	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
2qj1r9f	PatienceandFortitude	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
gf7yw	canon12	messaged_successfully	legacy_data_migration	2023-10-13T10:00:01.262844	author	\N	\N	\N
